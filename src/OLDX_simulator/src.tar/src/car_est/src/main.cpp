#include <ros/ros.h>
#include <std_msgs/String.h>
#include <std_msgs/Float32.h>
#include <std_msgs/Float64.h>
#include <std_msgs/ByteMultiArray.h>
#include <geometry_msgs/TwistStamped.h>
#include <geometry_msgs/Vector3.h> 
#include <nav_msgs/Odometry.h> 
#include <iostream>
#include <sstream>
#include <string>
#include <iomanip>
#include <opencv2/opencv.hpp>
#include <fstream>
#include<ctime>  
using std::cout;
using std::endl;
using namespace std;

float To_180_degrees(float x)
{
	return (x>180?(x-360):(x<-180?(x+360):x));
}

void q_to_eular(float x,float y,float z,float w,float att[3],float off)
{

att[0] = atan2(2 * (y*z + w*x), w*w - x*x - y*y + z*z)*57.3;
att[1] = asin(-2 * (x*z - w*y))*57.3;
att[2] = atan2(2 * (x*y + w*z), w*w + x*x - y*y - z*z)*57.3;
att[2] = To_180_degrees(atan2(2 * (-x*y - w*z), 2*(w*w+x*x)-1)*57.3+off);

}

//odom_car  [nav_msgs/Odometry]
nav_msgs::Odometry car;
float att_car[3];
void car_cb(const nav_msgs::Odometry &msg)
{
static int show;
 if(show++>10){show=0;
    //ROS_INFO("Received a car odom message!");  
    //ROS_INFO("Car Position:[%f,%f,%f]",msg.pose.pose.position.x ,msg.pose.pose.position.y,msg.pose.pose.position.z);  
    //ROS_INFO("CAR Spd Components:[%f,%f,%f]",-msg.twist.twist.linear.x,msg.twist.twist.linear.y,msg.twist.twist.angular.z);  
}
	car=msg;
  q_to_eular(msg.pose.pose.orientation.x,msg.pose.pose.orientation.y,
	msg.pose.pose.orientation.z,msg.pose.pose.orientation.w,att_car,-90);
}

nav_msgs::Odometry drone;
float att_drone[3];
void drone_cb(const nav_msgs::Odometry &msg)
{
static int show;
    //ROS_INFO("Received a drone odom message!");  
    //ROS_INFO("Drone Position:[%f,%f,%f]",msg.pose.pose.position.x ,msg.pose.pose.position.y,msg.pose.pose.position.z);  
    //ROS_INFO("Spd Components:[%f,%f,%f]",msg.twist.twist.linear.x,msg.twist.twist.linear.y,msg.twist.twist.angular.z);  
	drone=msg;
	q_to_eular(msg.pose.pose.orientation.x,msg.pose.pose.orientation.y,
	msg.pose.pose.orientation.z,msg.pose.pose.orientation.w,att_drone,90);
 if(show++>10){show=0;
  //ROS_INFO("Drone Att:[%f,%f,%f]",att_drone[0],att_drone[1],att_drone[2]);  
  //ROS_INFO("Car Att:[%f,%f,%f]",att_car[0],att_car[1],att_car[2]);  
  }
}

nav_msgs::Odometry w2c;
void w2c_cb(const nav_msgs::Odometry &msg)
{
static int show; 
    w2c=msg;
 if(show++>10){show=0;
  //ROS_INFO("W2C Position:[%f,%f,%f]",msg.pose.pose.position.x ,msg.pose.pose.position.y,msg.pose.pose.position.z);   
  //ROS_INFO("Car Att:[%f,%f,%f]",att_car[0],att_car[1],att_car[2]);  
  }
}

float p_d_c[4];
void calculate_drone_in_car_coordinate(void)
{
   float temp[2];
   float yaw_d_c=To_180_degrees(att_drone[2]-att_car[2]);
   if(drone.pose.pose.position.z!=0&&car.pose.pose.position.x!=0){
   temp[0]=-(drone.pose.pose.position.x-car.pose.pose.position.x);
   temp[1]=-(drone.pose.pose.position.y-car.pose.pose.position.y);
   //rotate to car coordinate
   float yaw_d_c1=-yaw_d_c;
   p_d_c[0]=cos(yaw_d_c1*0.0173)*temp[0]-sin(yaw_d_c1*0.0173)*temp[1];
   p_d_c[1]=sin(yaw_d_c1*0.0173)*temp[0]+cos(yaw_d_c1*0.0173)*temp[1];
   p_d_c[2]=drone.pose.pose.position.z-car.pose.pose.position.z;
   p_d_c[3]=yaw_d_c;
   }else
   p_d_c[0]=p_d_c[1]=p_d_c[2]=p_d_c[3]=0;
  static int show;
  if(show++>10){show=0;
    //cout<<"temp : "<<temp[0]<<" "<<temp[1]<<endl;
    //ROS_INFO("P dc:[%f,%f,%f,%f]",p_d_c[0],p_d_c[1],p_d_c[2],yaw_d_c);  
  }
}

float flt_w2c_true_set=0.88;
float kf_gain=1-0.01;//trust to est
float p_dc_est[4],p_dc_m[4];
int w2c_init=0;
int w2c_init_cnt=0;
void car_estimator(float dt)
{
 float p_dc_flt[4],pm_dn_flt[4],flt_w2c_true;
 int init_sel=1;
 float temp[2];
 float yaw_d_c;
 float dis_cd=sqrt(pow(w2c.pose.pose.position.x-drone.pose.pose.position.x,2)+pow(w2c.pose.pose.position.y-drone.pose.pose.position.y,2));
 //------------pos_measure
 p_dc_m[0]=p_dc_m[1]=p_dc_m[2]=p_dc_m[3]=0;
 int measure_ok=0; 
 if(w2c.twist.twist.angular.x!=0||dis_cd<0.35){
 measure_ok=1;
 flt_w2c_true=flt_w2c_true_set;
 //if(dis_cd<0.45){flt_w2c_true=0.05;cout<<"closet measure!!"<<endl;}
 p_dc_flt[0]=w2c.pose.pose.position.x   ;
 p_dc_flt[1]=w2c.pose.pose.position.y   ;
 p_dc_flt[2]=flt_w2c_true*w2c.pose.pose.position.z   +(1-flt_w2c_true)*car.pose.pose.position.z;
 p_dc_flt[3]=w2c.twist.twist.angular.x  ;
 //p_dc_flt[3]=w2c.twist.twist.angular.x;
 yaw_d_c=To_180_degrees(att_drone[2]-p_dc_flt[3]);
 temp[0]=cos(-yaw_d_c*0.0173)*p_dc_flt[0]-sin(-yaw_d_c*0.0173)*p_dc_flt[1];
 temp[1]=sin(-yaw_d_c*0.0173)*p_dc_flt[0]+cos(-yaw_d_c*0.0173)*p_dc_flt[1];
 p_dc_m[0]=pm_dn_flt[0]=flt_w2c_true*(drone.pose.pose.position.x-temp[0]) +(1-flt_w2c_true)*car.pose.pose.position.x;
 p_dc_m[1]=pm_dn_flt[1]=flt_w2c_true*(drone.pose.pose.position.y-temp[1]) +(1-flt_w2c_true)*car.pose.pose.position.y;
 p_dc_m[2]=pm_dn_flt[2]=drone.pose.pose.position.z-p_dc_flt[2];
 p_dc_m[3]=pm_dn_flt[3]=To_180_degrees(flt_w2c_true*yaw_d_c +(1-flt_w2c_true)*att_car[2]);
 }

 //------------spd_measure
 float car_spd[3];
 if(car.twist.twist.linear.x!=0){
 car_spd[0]=-car.twist.twist.linear.x;
 car_spd[1]=car.twist.twist.linear.y;
 car_spd[2]=-car.twist.twist.angular.z;
 }
 
 //------------------kf init
 if(w2c_init==0&&w2c.twist.twist.angular.x!=0){
  w2c_init_cnt++;
		  if(w2c_init_cnt>10){
		  w2c_init=1;
	          w2c_init_cnt=0;
			  switch(init_sel){
			  case 0:
			  //init with real pos	
			  p_dc_est[0]=car.pose.pose.position.x;
			  p_dc_est[1]=car.pose.pose.position.y;
			  p_dc_est[2]=car.pose.pose.position.z;
			  p_dc_est[3]=att_car[2];
			  break;
			  case 1:
			  //init with w2c pos
			  p_dc_est[0]=pm_dn_flt[0];
			  p_dc_est[1]=pm_dn_flt[1];
			  p_dc_est[2]=pm_dn_flt[2];
			  p_dc_est[3]=pm_dn_flt[3];
		           ROS_INFO("init RP:[%f,%f,%f,%f]",car.pose.pose.position.x,car.pose.pose.position.y
			  ,car.pose.pose.position.z,att_car[2]);  
 			   ROS_INFO("init P:[%f,%f,%f,%f]",p_dc_est[0],p_dc_est[1],p_dc_est[2],p_dc_est[3]);  
			  break;
			  }
		  }
  if(w2c.twist.twist.angular.x==0)
   w2c_init_cnt=0;

 }
 

 if(w2c_init){
 //--------------kf  est
 p_dc_est[0]+=car_spd[0]*sin(p_dc_est[3]*0.0173)*dt;
 p_dc_est[1]+=car_spd[0]*cos(p_dc_est[3]*0.0173)*dt;
 p_dc_est[3]+=car_spd[2]*dt*57.3;
 //--------------kf  correct
	if(measure_ok){
	p_dc_est[0]=p_dc_est[0]*kf_gain+(1-kf_gain)*pm_dn_flt[0];
	p_dc_est[1]=p_dc_est[1]*kf_gain+(1-kf_gain)*pm_dn_flt[1];
	p_dc_est[2]=p_dc_est[2]*kf_gain+(1-kf_gain)*pm_dn_flt[2];
	p_dc_est[3]=p_dc_est[3]*kf_gain+(1-kf_gain)*pm_dn_flt[3];
	}
 }
}

int main(int argc, char *argv[])
{	static int cnt_show;
	ros::init(argc, argv, "car_est");
	ros::NodeHandle nh;
        ros::Subscriber sub_car = nh.subscribe("/odom_car", 1, car_cb); 
 	ros::Subscriber sub_drone = nh.subscribe("/ground_truth/state", 1, drone_cb); 
	ros::Subscriber sub_w2c = nh.subscribe("/w2c_pos", 1, w2c_cb); 
        ros::Publisher  pub_car_est = nh.advertise<nav_msgs::Odometry>("car_est", 1);
	ros::Rate loop_rate(100);
	ros::Time last_request = ros::Time::now();
   	cout<<"estimator start!"<<endl;
	while (ros::ok())
	{clock_t start,finish;  
	start=clock();  
		calculate_drone_in_car_coordinate();
		
		car_estimator(0.01);

		nav_msgs::Odometry temp;
		if(w2c_init){
	        //est
		temp.pose.pose.position.x =p_dc_est[0];
		temp.pose.pose.position.y =p_dc_est[1];
		temp.pose.pose.position.z =p_dc_est[2];
		temp.twist.twist.angular.x=p_dc_est[3];
		//measure
		temp.twist.twist.linear.x =p_dc_m[0];
		temp.twist.twist.linear.y =p_dc_m[1];
		temp.twist.twist.linear.z =p_dc_m[2];
		temp.twist.twist.angular.z=p_dc_m[3];
	        
			if(cnt_show++>10){cnt_show=0;
			cout<<"real car: "<<car.pose.pose.position.x<<" "<<car.pose.pose.position.y<<" "<<
			car.pose.pose.position.z<<" "<<att_car[2]<<endl;
			cout<<"measurement: "<<p_dc_m[0]<<" "<<p_dc_m[1]<<" "<<p_dc_m[2]<<" "<<p_dc_m[3]<<endl;
			cout<<"ests car: "<<p_dc_est[0]<<" "<<p_dc_est[1]<<" "<<p_dc_est[2]<<" "<<p_dc_est[3]<<endl;
			cout<<"------------"<<endl;
			}
		}
 		pub_car_est.publish(temp);
		ros::spinOnce();

		loop_rate.sleep();
	}
	return 0;
}
