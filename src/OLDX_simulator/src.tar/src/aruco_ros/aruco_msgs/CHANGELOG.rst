^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package aruco_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2015-08-10)
------------------
* Update changelogs and maintainer email
* Contributors: Bence Magyar

0.0.1 (2015-05-20)
------------------
* Reorganize aruco_ros into 3 packages
* Contributors: Bence Magyar
