#include <ros/ros.h>
#include <serial/serial.h>
#include <serial/v8stdint.h>
#include <std_msgs/String.h>
#include <std_msgs/Float32.h>
#include <std_msgs/Float64.h>
#include <std_msgs/ByteMultiArray.h>
#include <geometry_msgs/TwistStamped.h>
#include <geometry_msgs/Vector3.h> 
#include <std_msgs/Empty.h>
#include <nav_msgs/Odometry.h> 
#include "oldx.h"
#include "plan.h"
#include <iostream>
#include <sstream>
#include <string>
#include <iomanip>
#include <opencv2/opencv.hpp>
#include <fstream>
#include<ctime>  
using std::cout;
using std::endl;
using namespace std;
serial::Serial m_serial;

float x = 0.0, y = 0.0, z = 0.0, yaw = 0.0, yaw_rad = 0.0;
float x_min=0.0,x_max=0.0,y_min=0.0,y_max=0.0,z_min=0.0,z_max=0.0,yaw_min=0.0,yaw_max=0.0;
float mode_tx;
geometry_msgs::Vector3 mode_rx;
std_msgs::ByteMultiArray data_to_send;
void oldx_send_cb(const std_msgs::ByteMultiArray::ConstPtr &msg)
{
	data_to_send.data.clear();
	data_to_send = *msg;
#ifdef DEBUG_COUT
	cout<<data_to_send<<endl;
#endif
}


float To_180_degrees(float x)
{
	return (x>180?(x-360):(x<-180?(x+360):x));
}

void q_to_eular(float x,float y,float z,float w,float att[3],float off)
{

att[0] = atan2(2 * (y*z + w*x), w*w - x*x - y*y + z*z)*57.3;
att[1] = asin(-2 * (x*z - w*y))*57.3;
att[2] = atan2(2 * (x*y + w*z), w*w + x*x - y*y - z*z)*57.3;
att[2] = To_180_degrees(atan2(2 * (-x*y - w*z), 2*(w*w+x*x)-1)*57.3+off);

}

//odom_car  [nav_msgs/Odometry]
nav_msgs::Odometry car;
float att_car[3];
void car_cb(const nav_msgs::Odometry &msg)
{
    //ROS_INFO("Received a car odom message!");  
    //ROS_INFO("Car Position:[%f,%f,%f]",msg.pose.pose.position.x ,msg.pose.pose.position.y,msg.pose.pose.position.z);  
    //ROS_INFO("Spd Components:[%f,%f,%f]",-msg.twist.twist.linear.x,msg.twist.twist.linear.y,msg.twist.twist.angular.z);  
	car=msg;
  q_to_eular(msg.pose.pose.orientation.x,msg.pose.pose.orientation.y,
	msg.pose.pose.orientation.z,msg.pose.pose.orientation.w,att_car,-90);
}

nav_msgs::Odometry car_est;
void car_est_cb(const nav_msgs::Odometry &msg)
{ 
   car_est=msg;
}

nav_msgs::Odometry w2c;
void w2c_cb(const nav_msgs::Odometry &msg)
{ 
   w2c=msg;
}

geometry_msgs::Twist  velocity_cmd_car;
float kp_car[2]={300,1},ki_car[2]={1,0.01};
void car_contral(float exp_y,float exp_z,float dt,int en_auto_run,float spd,float rad)
{
  float err[2];
  static float inter[2]={0,0};
  
  err[0]=(exp_y-(-car.twist.twist.linear.x));
  inter[0]+= err[0]*ki_car[0];
  velocity_cmd_car.linear.x=exp_y*2;//(err[0]*kp_car[0]+inter[0])*1;

  static int cnt,show;
  int flag;
  if(cnt++>20){cnt=0;
   if(flag)flag=0;
    else flag=1;}


  err[1]=exp_z-car.twist.twist.angular.z;
  inter[1]+= err[1]*ki_car[1];
  velocity_cmd_car.angular.z=(err[1]*kp_car[1]+inter[1])*0;

  if(en_auto_run)
  velocity_cmd_car.linear.x=spd;velocity_cmd_car.angular.z=rad;//<-----circle cmd

  if(show++>10){show=0;
  //ROS_INFO("Car Cmd:[%f,%f,%f,%f]",velocity_cmd_car.linear.x,err[0],-car.twist.twist.linear.x,exp_y);  
  // ROS_INFO("Car Spd Components:[%f,%f,%f]",car.twist.twist.linear.x,car.twist.twist.linear.y,car.twist.twist.angular.z);  
  }
}




nav_msgs::Odometry drone;
float att_drone[3];
void drone_cb(const nav_msgs::Odometry &msg)
{
static int show;
    //ROS_INFO("Received a drone odom message!");  
    //ROS_INFO("Drone Position:[%f,%f,%f]",msg.pose.pose.position.x ,msg.pose.pose.position.y,msg.pose.pose.position.z);  
    //ROS_INFO("Spd Components:[%f,%f,%f]",msg.twist.twist.linear.x,msg.twist.twist.linear.y,msg.twist.twist.angular.z);  
	drone=msg;
	q_to_eular(msg.pose.pose.orientation.x,msg.pose.pose.orientation.y,
	msg.pose.pose.orientation.z,msg.pose.pose.orientation.w,att_drone,90);
 if(show++>10){show=0;
  //ROS_INFO("Drone Att:[%f,%f,%f]",att_drone[0],att_drone[1],att_drone[2]);  
  //ROS_INFO("Car Att:[%f,%f,%f]",att_car[0],att_car[1],att_car[2]);  
  }
}

geometry_msgs::Twist  velocity_cmd_drone;
float kp_drone[3]={0.88,0.56,0.068},ki_drone[3]={0.001,0.001,0.001};
void drone_contral(float exp_x,float exp_y,float exp_z,float exp_yaw,float dt,float limit)
{
  float err[4];
  static float inter[4]={0,0};
  float temp[2];
  err[0]=(exp_x-(drone.pose.pose.position.x));
  inter[0]+= err[0]*ki_drone[0];
  inter[0]=LIMIT(inter[0],-0.3,0.3);
  temp[0]=(err[0]*kp_drone[0]+inter[0])*1;

  err[1]=(exp_y-(drone.pose.pose.position.y));
  inter[1]+= err[1]*ki_drone[0];
 inter[1]=LIMIT(inter[1],-0.3,0.3);
  temp[1]=(err[1]*kp_drone[0]+inter[1])*1;

  err[2]=(exp_z-(drone.pose.pose.position.z));
  inter[2]+= err[2]*ki_drone[1];
 inter[2]=LIMIT(inter[2],-0.3,0.3);
  velocity_cmd_drone.linear.z=LIMIT((err[2]*kp_drone[1]+inter[2])*1,-limit,limit);

  velocity_cmd_drone.linear.x=LIMIT( temp[1]*cos(att_drone[2]*0.0173)+temp[0]*sin(att_drone[2]*0.0173),-limit,limit); 
  velocity_cmd_drone.linear.y=-LIMIT(-temp[1]*sin(att_drone[2]*0.0173)+temp[0]*cos(att_drone[2]*0.0173),-limit,limit);

  err[3]=To_180_degrees(exp_yaw-att_drone[2]);
  inter[3]+= err[3]*ki_drone[2];
  inter[3]=LIMIT(inter[3],-0.3,0.3);
  velocity_cmd_drone.angular.z=-LIMIT((err[3]*kp_drone[2]+inter[3])*1,-4,4);

  static int show;
  if(show++>10){show=0;
  //ROS_INFO("Drone POS:[%f,%f,%f,%f]",drone.pose.pose.position.x,drone.pose.pose.position.y,drone.pose.pose.position.z);  
  //ROS_INFO("Drone Spd Components:[%f,%f,%f]",drone.twist.twist.linear.x,drone.twist.twist.linear.y,drone.twist.twist.angular.z);  
  //ROS_INFO("Drone Cmd:[%f,%f,%f,%f]",velocity_cmd_drone.linear.x,velocity_cmd_drone.linear.y,velocity_cmd_drone.linear.z);  
  }
}

float p_d_c[3];
void calculate_drone_in_car_coordinate(void)
{
   float temp[2];
   float yaw_d_c=To_180_degrees(att_drone[2]-att_car[2]);
   if(drone.pose.pose.position.z!=0&&car.pose.pose.position.x!=0){
   temp[0]=-(drone.pose.pose.position.x-car.pose.pose.position.x);
   temp[1]=-(drone.pose.pose.position.y-car.pose.pose.position.y);
   //rotate to car coordinate
   float yaw_d_c1=-yaw_d_c;
   p_d_c[0]=cos(yaw_d_c1*0.0173)*temp[0]-sin(yaw_d_c1*0.0173)*temp[1];
   p_d_c[1]=sin(yaw_d_c1*0.0173)*temp[0]+cos(yaw_d_c1*0.0173)*temp[1];
   p_d_c[2]=drone.pose.pose.position.z-car.pose.pose.position.z;
   }else
   p_d_c[0]=p_d_c[1]=p_d_c[2];
  static int show;
  if(show++>10){show=0;
    //cout<<"temp : "<<temp[0]<<" "<<temp[1]<<endl;
    //ROS_INFO("P dc:[%f,%f,%f,%f]",p_d_c[0],p_d_c[1],p_d_c[2],yaw_d_c);  
  }
}

geometry_msgs::Twist  velocity_ar_key;
void key_cb(const geometry_msgs::Twist &cmd_vel)
{
   // ROS_INFO("Received a /cmd_vel message!");  
   // ROS_INFO("Linear Components:[%f,%f,%f]",cmd_vel.linear.x,cmd_vel.linear.y,cmd_vel.linear.z);  
   // ROS_INFO("Angular Components:[%f,%f,%f]",cmd_vel.angular.x,cmd_vel.angular.y,cmd_vel.angular.z);  
	velocity_ar_key=cmd_vel;
}

void save_cb(const std_msgs::Empty &msg)
{
	if(mode_rx.y==0)
		mode_rx.y=1;
}

void stop_save_cb(const std_msgs::Empty &msg)
{
	if(mode_rx.y==1)
		{mode_rx.y=0;cout<<"Stop TxT Saving !!"<<endl;}
}


void SEND_PX4(void)
{
	// cout<<"*****"<<endl;
	m_serial.write((unsigned char *)data_to_send.data.data(), data_to_send.data.size());
}

bool checkcommand(const unsigned char *data_buf, int data_length)
{
	if (!(*(data_buf) == 0xFA && *(data_buf + 1) == 0xFB && *(data_buf + 2) == 0x04 && *(data_buf + 3) == 0x01))
	{
		return false; //判断帧头
	}
	if (*(data_buf + data_length - 1) != 0xFE)
	{
		return false;
	}
	return true;
}

int data_save[50];
void decode(const unsigned char *data_buf, int data_length)
{
	int16_t temp = 0,i,j; //temp==>mm, x==>m
	unsigned char mode = data_buf[4];
	temp = data_buf[5];
	temp <<= 8;
	temp |= data_buf[6];
	x = (float)temp / 1000;
	temp = data_buf[7];
	temp <<= 8;
	temp |= data_buf[8];
	y = (float)temp / 1000;
	temp = data_buf[9];
	temp <<= 8;
	temp |= data_buf[10];
	z = (float)temp / 1000;
	temp = data_buf[11];
	temp <<= 8;
	temp |= data_buf[12];
	yaw = (float)temp / 100; //degree
        mode_rx.y=data_buf[13];//data
	mode_rx.z=data_buf[14];//video
	
	for(i=0;i<11;i++){
	temp = data_buf[15+i*2];
	temp <<= 8;
	temp |= data_buf[15+i*2+1];
	//data_save[i]=temp;
	}
	x = LIMIT(x, x_min, x_max);
	y = LIMIT(y, y_min, y_max);
	z = LIMIT(z, z_min, z_max);
	yaw = LIMIT(yaw, yaw_min, yaw_max);
	yaw_rad = -1 * yaw / 57.3;
	mode_rx.x=mode_tx=mode;	
	static int cnt;
	if(cnt++>40){cnt=0;
	//cout << x << " " << y << " " << z << " " << yaw <<" "<<mode_rx<<"end"<<endl;
	} 
}


void save_file_set(void)
{
float temp[10];
//drone real pose
data_save[0]=drone.pose.pose.position.x*100;
data_save[1]=drone.pose.pose.position.y*100;
data_save[2]=drone.pose.pose.position.z*100;
data_save[3]=att_drone[2]*100;
//car real pose
data_save[4]=car.pose.pose.position.x*100;
data_save[5]=car.pose.pose.position.y*100;
data_save[6]=att_car[2]*100;
//expect drone body spd
data_save[7]=velocity_cmd_drone.linear.x*100;
data_save[8]=velocity_cmd_drone.linear.y*100;
data_save[9]=velocity_cmd_drone.linear.z*100;
//drone body spd
temp[0]=drone.twist.twist.linear.y*1*cos(att_drone[2]/57.3)+drone.twist.twist.linear.x*sin(att_drone[2]/57.3);
temp[1]=drone.twist.twist.linear.y*-1*sin(att_drone[2]/57.3)+drone.twist.twist.linear.x*cos(att_drone[2]/57.3);
data_save[10]=temp[0]*100;
data_save[11]=-temp[1]*100;
data_save[12]=drone.twist.twist.linear.z*100;
//car body spd
temp[2]=car.twist.twist.linear.y*1*cos(att_car[2]/57.3)+car.twist.twist.linear.x*sin(att_car[2]/57.3);
temp[3]=car.twist.twist.linear.y*-1*sin(att_car[2]/57.3)+car.twist.twist.linear.x*cos(att_car[2]/57.3);
data_save[13]=temp[2]*100;
data_save[14]=temp[3]*100;
//car est
data_save[15]=car_est.pose.pose.position.x*100;
data_save[16]=car_est.pose.pose.position.y*100;
data_save[17]=car_est.twist.twist.angular.x*100;
//car measure
data_save[18]=car_est.twist.twist.linear.x*100;
data_save[19]=car_est.twist.twist.linear.y*100;
data_save[20]=car_est.twist.twist.angular.z*100;
//circle tag
data_save[21]=w2c.pose.pose.position.x*100;
data_save[22]=w2c.pose.pose.position.y*100;
data_save[23]=w2c.pose.pose.position.z*100;
//2d tag
data_save[24]=w2c.twist.twist.linear.x*100;
data_save[25]=w2c.twist.twist.linear.y*100;
data_save[26]=w2c.twist.twist.linear.z*100;
//real visual
data_save[27]=p_d_c[0]*100;
data_save[28]=p_d_c[1]*100;
data_save[29]=p_d_c[2]*100;
}

int video_num = 0;
int write_flag;
int newfile_flag;
std::ifstream video_num_read;
std::ofstream video_num_write;
std::string video_num_path("/home/exbot/DATA_SAVE_LAND/file_num.txt");
std::string writer_path("/home/exbot/DATA_SAVE_LAND/");


void startWriteFile(std::ofstream &writer_txt,float dt)
{   static int init_for_map_est=0;
    int i;
    std::stringstream ss;
    static string file_name;
	
    if(newfile_flag==1){
    video_num_read.open(video_num_path.c_str());
    video_num_read >> video_num;
    video_num_read.close();

    newfile_flag=2;
    video_num=video_num+1;
    video_num_write.open(video_num_path.c_str());
    video_num_write << (video_num );
    video_num_write.close();
    ss << video_num;
    ss >> file_name;
    file_name += ".txt";
    writer_txt.open((writer_path + file_name).c_str());
    cout<<"data write path:"<<writer_path+file_name<<endl;
   }
 
   
 if(newfile_flag==2)
    writer_txt<<(int)(dt*1000)<<"\t"<<data_save[0]<<"\t"<<data_save[1]<<"\t"<<
    data_save[2]<<"\t"<<data_save[3]<<"\t"<<data_save[4]<<"\t"<<
    data_save[5]<<"\t"<<data_save[6]<<"\t"<<data_save[7]<<"\t"<<
    data_save[8]<<"\t"<<data_save[9]<<"\t"<<data_save[10]<<"\t"<<
    data_save[11]<<"\t"<<data_save[12]<<"\t"<<data_save[13]<<"\t"<<data_save[14]<<"\t"<<
    data_save[15]<<"\t"<<data_save[16]<<"\t"<<data_save[17]<<"\t"<<data_save[18]<<"\t"<<
    data_save[19]<<"\t"<<data_save[20]<<"\t"<<
    data_save[21]<<"\t"<<data_save[22]<<"\t"<<data_save[23]<<"\t"<<data_save[24]<<"\t"<<
    data_save[25]<<"\t"<<data_save[26]<<"\t"<<data_save[27]<<"\t"<<data_save[28]<<"\t"<<data_save[29]
    <<endl;
}
#define USE_SERIAL 0
#define EN_AUTO_LAND 1
int main(int argc, char *argv[])
{
	ros::init(argc, argv, "oldx_serial");
	ros::NodeHandle nh;
	ros::Publisher velocity_pub = nh.advertise<geometry_msgs::TwistStamped>("oldx/velocity", 1);
	ros::Publisher mode_pub = nh.advertise<geometry_msgs::Vector3>("mode_fc", 1);
	ros::Subscriber sub = nh.subscribe("oldx/oldx_send", 1, oldx_send_cb);
	ros::Subscriber sub_key = nh.subscribe("cmd_vel_k", 1, key_cb);

        ros::Subscriber sub_car = nh.subscribe("/odom_car", 1, car_cb); 
 	ros::Subscriber sub_drone = nh.subscribe("/ground_truth/state", 1, drone_cb); 
	ros::Subscriber sub_car_est = nh.subscribe("/car_est", 1, car_est_cb); 
	ros::Subscriber sub_w2c = nh.subscribe("/w2c_pos", 1, w2c_cb); 

	ros::Subscriber sub_save = nh.subscribe("/txt_save", 1, save_cb);
	ros::Subscriber sub_stop_save = nh.subscribe("/stop_txt_save", 1, stop_save_cb);
        ///cmd_vel geometry_msgs/Twist
	ros::Publisher velocity_pub_ar = nh.advertise<geometry_msgs::Twist>("/cmd_vel", 1);
	ros::Publisher velocity_pub_car = nh.advertise<geometry_msgs::Twist>("/cmd_vel_car", 1);
	std::string port_name;
	int baudrate = 230400;
	serial::Timeout timeout(serial::Timeout::simpleTimeout(1000));
	ros::param::get("~port_name", port_name);
	ros::param::get("~baudrate", baudrate);
	ros::param::get("~x_min", x_min);
	ros::param::get("~x_max", x_max);
	ros::param::get("~y_min", y_min);
	ros::param::get("~y_max", y_max);
	ros::param::get("~z_min", z_min);
	ros::param::get("~z_max", z_max);
	ros::param::get("~yaw_min", yaw_min);
	ros::param::get("~yaw_max", yaw_max);

	ROS_INFO("serial port name:%s", port_name.c_str());
	ROS_INFO("serial baudrate:%d", baudrate);
#if USE_SERIAL
	m_serial.setPort(port_name);
	m_serial.setBaudrate(baudrate);
	m_serial.setTimeout(timeout);
	m_serial.open();
	if (!m_serial.isOpen())
	{
		cout << "serial open failed!" << endl;
		return -1;
	}
#endif
	size_t data_length = 0;
	unsigned char sum = 0;
	unsigned char data_buf[BUFF_SIZE] = {0};
	int16_t temp = 0;

	geometry_msgs::TwistStamped velocity;
	geometry_msgs::Twist  velocity_ar;
		
	ros::Rate loop_rate(100);
	std::ofstream file_writer;
	ros::Time last_request = ros::Time::now();
   
	while (ros::ok())
	{clock_t start,finish;  
	start=clock();  
#if USE_SERIAL
		data_length = m_serial.available();
		if (data_length)
		{
			m_serial.read(data_buf, data_length);
			if (checkcommand(data_buf, data_length))
			{
				decode(data_buf, data_length);
			}
		}
#endif
		velocity.twist.linear.x = x;
		velocity.twist.linear.y = y;
		velocity.twist.linear.z = z;

		velocity.twist.angular.z = yaw_rad;
		velocity.twist.angular.x = mode_tx;
		velocity_pub.publish(velocity);
		mode_pub.publish(mode_rx);
#if USE_SERIAL
		SEND_PX4();
#endif
		calculate_drone_in_car_coordinate();
                //
static int state_plan;
static float t_now=0;
static float t_max[3]={10,10,4};
float Dt=0.010;
#define WAY_DEAD 0.45
float yaw_exp;
float R1=2,R2=0.7;
float H1=2.3,H2=1.68;
float car_plan_pos[4];
float car_max_spd=2;
int plan_pose_sel=0;//1<-w2c
float fp_gain=0.4;
int car_move_sel=0;//0>------circle
float x_pre=fp_gain*sin(att_car[2]/57.3);
float y_pre=fp_gain*cos(att_car[2]/57.3);
//----car est sel
switch(plan_pose_sel){
case 0://true
car_plan_pos[0]=car.pose.pose.position.x+x_pre*fp_gain;
car_plan_pos[1]=car.pose.pose.position.y+y_pre*fp_gain;
car_plan_pos[3]=att_car[2];
break;
case 1://w2c
car_plan_pos[0]=car_est.pose.pose.position.x;
car_plan_pos[1]=car_est.pose.pose.position.y;
car_plan_pos[3]=car_est.twist.twist.angular.x;
break;
}
float spd_yaw_car=(car_plan_pos[3])/57.3;
float    xp1=car_plan_pos[0]-R1*sin(spd_yaw_car);
float    yp1=car_plan_pos[1]-R1*cos(spd_yaw_car);
float    xp2=car_plan_pos[0]-R2*sin(spd_yaw_car);
float    yp2=car_plan_pos[1]-R2*cos(spd_yaw_car);
//------ ---landing planner-----
float around_dis=3.6;
float dis_dc;
int scuess;
float land_score[3];
int en_car_move=0;
float spd_yaw_carr=(att_car[2])/57.3;
float    xpr=car.pose.pose.position.x-around_dis*sin(spd_yaw_carr);
float    ypr=car.pose.pose.position.y-around_dis*cos(spd_yaw_carr);
#if EN_AUTO_LAND
switch(state_plan){
case 0:
	yaw_exp=atan2(car.pose.pose.position.x-drone.pose.pose.position.x, 
					 car.pose.pose.position.y-drone.pose.pose.position.y)*57.3;

        velocity_cmd_drone.linear.x=velocity_cmd_drone.linear.y=velocity_cmd_drone.linear.z=velocity_cmd_drone.angular.z=0;
	//drone_contral(car.pose.pose.position.x+around_dis*0,car.pose.pose.position.y+around_dis,3,yaw_exp,Dt,6);
	drone_contral(xpr,ypr,2.3,yaw_exp,Dt,6);
        if(velocity_ar_key.linear.x+velocity_ar_key.linear.y+velocity_ar_key.linear.z+velocity_ar_key.angular.z!=0)
            state_plan=1;
break;
case 1:en_car_move=1;
	if(velocity_ar_key.linear.x+velocity_ar_key.linear.y+velocity_ar_key.linear.z+velocity_ar_key.angular.z==0)
		t_now=t_now+Dt;     
	else
       		t_now=0;
		yaw_exp=atan2(car.pose.pose.position.x-drone.pose.pose.position.x, 
					 car.pose.pose.position.y-drone.pose.pose.position.y)*57.3;
		drone_contral(car.pose.pose.position.x,car.pose.pose.position.y,H1,att_drone[2]*0+yaw_exp,Dt,abs(car.twist.twist.linear.x)*2);
	if(t_now>4)
		{state_plan=2;t_now=0;land_score[0]=land_score[1]=land_score[2]=0;mode_rx.y=1;}

break;
case 2:en_car_move=1;
		dis_dc=sqrt(pow(drone.pose.pose.position.x-xp1,2)+pow(drone.pose.pose.position.y-yp1,2));
		land_score[0]+=Dt;
		traj[0].ps[0]=drone.pose.pose.position.x;
		traj[0].ps[1]=drone.pose.pose.position.y;
		traj[0].ps[2]=drone.pose.pose.position.z;
		traj[0].pe[0]=xp1;
		traj[0].pe[1]=yp1;
		traj[0].pe[2]=H1;
		traj[0].vs[0]=0;//drone.twist.twist.linear.x;
		traj[0].vs[1]=0;//drone.twist.twist.linear.y;
		traj[0].ve[0]=0;//drone.twist.twist.linear.x;
		traj[0].ve[1]=0;//drone.twist.twist.linear.y;
		//traj[0].ve[0]=car.twist.twist.linear.x*1*cos(att_car[2]/57.3)+car.twist.twist.linear.y*sin(att_car[2]/57.3);
		//traj[0].ve[1]=car.twist.twist.linear.x*-1*sin(att_car[2]/57.3)+car.twist.twist.linear.y*cos(att_car[2]/57.3);
                traj[0].Time=t_max[0]-t_now;
                traj[0].defined[0]=traj[0].defined[1]=traj[0].defined[2]=1;
	  	plan_tra(&traj[0]);		

		yaw_exp=atan2(car.pose.pose.position.x-drone.pose.pose.position.x, 
					 car.pose.pose.position.y-drone.pose.pose.position.y)*57.3;
		t_now=t_now+Dt;
		
		get_tra(&traj[0],LIMIT(t_now,0,traj[0].Time));
		//cout<<"exp_x :"<<traj[0].pt[0]<<"  exp_y :"<<traj[0].pt[1]<<"  exp_z :"<<traj[0].pt[2]<<" dis_dc:"<<dis_dc<<" T:"<<t_now<<endl;
		drone_contral(traj[0].pt[0],traj[0].pt[1],traj[0].pt[2],att_drone[2]*0+yaw_exp,Dt,4);
		
		 if(velocity_ar_key.linear.x+velocity_ar_key.linear.y+velocity_ar_key.linear.z+velocity_ar_key.angular.z!=0)
		    state_plan=0;
		if(fabs(dis_dc)<WAY_DEAD){state_plan=3;t_now=t_max[1]*0.2;}
break;
case 3:en_car_move=1;
		dis_dc=sqrt(pow(drone.pose.pose.position.x-xp2,2)+pow(drone.pose.pose.position.y-yp2,2));land_score[0]+=Dt;
		traj[0].ps[0]=drone.pose.pose.position.x;
		traj[0].ps[1]=drone.pose.pose.position.y;
		traj[0].ps[2]=drone.pose.pose.position.z;
		traj[0].pe[0]=xp2;
		traj[0].pe[1]=yp2;
		traj[0].pe[2]=H2;
		traj[0].ve[0]=0;//drone.twist.twist.linear.x;
		traj[0].ve[1]=0;//drone.twist.twist.linear.y;
		//traj[0].ve[0]=car.twist.twist.linear.x*1*cos(att_car[2]/57.3)+car.twist.twist.linear.y*sin(att_car[2]/57.3);
		//traj[0].ve[1]=car.twist.twist.linear.x*-1*sin(att_car[2]/57.3)+car.twist.twist.linear.y*cos(att_car[2]/57.3);
                traj[0].Time=t_max[1]-t_now;
                traj[0].defined[0]=traj[0].defined[1]=traj[0].defined[2]=1;
	  	plan_tra(&traj[0]);		

		yaw_exp=atan2(car.pose.pose.position.x-drone.pose.pose.position.x, 
					 car.pose.pose.position.y-drone.pose.pose.position.y)*57.3;
		t_now=t_now+Dt;
		
		get_tra(&traj[0],LIMIT(t_now,0,traj[0].Time));
		//cout<<"exp_x :"<<traj[0].pt[0]<<"  exp_y :"<<traj[0].pt[1]<<"  exp_z :"<<traj[0].pt[2]<<" dis_dc:"<<dis_dc<<" T:"<<t_now<<endl;
		drone_contral(traj[0].pt[0],traj[0].pt[1],traj[0].pt[2],att_drone[2]*0+yaw_exp,Dt,4);
		
		 if(velocity_ar_key.linear.x+velocity_ar_key.linear.y+velocity_ar_key.linear.z+velocity_ar_key.angular.z!=0)
		    state_plan=0;
		if(fabs(dis_dc)<WAY_DEAD){state_plan=4;t_now=t_max[2]*0.2;}
break;
case 4:en_car_move=1;
		dis_dc=sqrt(pow(drone.pose.pose.position.x-car.pose.pose.position.x,2)+pow(drone.pose.pose.position.y-car.pose.pose.position.y,2));land_score[0]+=Dt;

		traj[0].ps[0]=drone.pose.pose.position.x;
		traj[0].ps[1]=drone.pose.pose.position.y;
		traj[0].ps[2]=drone.pose.pose.position.z;
		traj[0].pe[0]=car_plan_pos[0];
		traj[0].pe[1]=car_plan_pos[1];
		traj[0].pe[2]=0.05;
		traj[0].vs[0]=drone.twist.twist.linear.x;
		traj[0].vs[1]=drone.twist.twist.linear.y;
		traj[0].ve[0]=car.twist.twist.linear.x*1*cos(att_car[2]/57.3)+car.twist.twist.linear.y*sin(att_car[2]/57.3);
		traj[0].ve[1]=car.twist.twist.linear.x*-1*sin(att_car[2]/57.3)+car.twist.twist.linear.y*cos(att_car[2]/57.3);
		traj[0].Time=t_max[2]-t_now;
                traj[0].defined[0]=traj[0].defined[1]=traj[0].defined[2]=1;
	  	plan_tra(&traj[0]);		

		yaw_exp=atan2(car.pose.pose.position.x-drone.pose.pose.position.x, 
					 car.pose.pose.position.y-drone.pose.pose.position.y)*57.3;
		t_now=t_now+Dt;
		
		get_tra(&traj[0],LIMIT(t_now,0,traj[0].Time));
		//cout<<"exp_x :"<<traj[0].pt[0]<<"  exp_y :"<<traj[0].pt[1]<<"  exp_z :"<<traj[0].pt[2]<<" T:"<<t_now<<endl;
		if(dis_dc<0.5)
		drone_contral(traj[0].pt[0],traj[0].pt[1],traj[0].pt[2],att_car[2],Dt,4);
		else
		drone_contral(traj[0].pt[0],traj[0].pt[1],traj[0].pt[2],yaw_exp,Dt,4);
		
		 if(velocity_ar_key.linear.x+velocity_ar_key.linear.y+velocity_ar_key.linear.z+velocity_ar_key.angular.z!=0)
		    state_plan=0;
		scuess=0;
		if(t_now>t_max[2]||fabs(drone.pose.pose.position.z)<traj[0].pe[2]*1.2){t_now=0;state_plan=5;
		land_score[1]=dis_dc;
		if(fabs(att_drone[0])<10&&fabs(att_drone[1])<10&&dis_dc<0.2)
			scuess=1;
		cout<<"Land Scor: "<<scuess<<"  "<<land_score[0]<<" s, "<<land_score[1]<<" m"<<endl;
		mode_rx.y=0;
		}
break;
case 5:
	//drone_contral(car.pose.pose.position.x+4,car.pose.pose.position.y+4,3,180,Dt,6);
	t_now=t_now+Dt;
	if(t_now>3.5){t_now=0;state_plan=6;}
break;
case 6:
	drone_contral(car.pose.pose.position.x+4,car.pose.pose.position.y+4,3,180,Dt,6);
	t_now=t_now+Dt;
	if(t_now>5){t_now=0;state_plan=0;}
break;
}
#endif	
if(car_move_sel==0)
 en_car_move=1;
		switch(car_move_sel){
		case 0:
		car_contral(0,0, Dt,1,car_max_spd*en_car_move,0.35*en_car_move);
		break;
		case 1:
		car_contral(0,0, Dt,1,car_max_spd*en_car_move,0);
		break;
		}
		//ar cmd_vel out
                 
		velocity_ar.linear.x = 0;//max=1.5 
	        if(velocity_ar_key.linear.x+velocity_ar_key.linear.y+velocity_ar_key.linear.z+velocity_ar_key.angular.z==0)
		velocity_pub_ar.publish(velocity_cmd_drone);
		else
		velocity_pub_ar.publish(velocity_ar_key);
			
		velocity_pub_car.publish(velocity_cmd_car);
		//saving
		static int save_state;
		//ros::Time dt=ros::Time::now() - last_request;
		finish=clock();  
		float dt=(float)( finish-start )/CLOCKS_PER_SEC;
		static float dt_s=0;
		int save_trig;
		dt_s+=dt;

		{save_trig=1;}
		save_file_set();
		switch(save_state)
		{
		 case 0:if(mode_rx.y==1)
		        {newfile_flag=1,save_state=1;}
			break;
		 case 1:
		       dt_s+=dt;
		       if(save_trig)
		       {
		       startWriteFile(file_writer,dt_s);
		        save_trig=0;
		       }
		       if(mode_rx.y==0)
		       {file_writer.close();newfile_flag=save_state=0;}
		       break;
		}
		
		ros::spinOnce();

		loop_rate.sleep();
	}

	cout << "serial quit" << endl;

	return 0;
}
