#ifndef __PLAN_H__
#define __PLAN_H__

typedef struct
{
 float pt[3];//expect
 float vt[3];
 float at[3];
 float ps[3];//start
 float vs[3];
 float as[3];
 float pe[3];//end
 float ve[3];
 float ae[3];
 float param[10];
 float Time;
 float cost;
 char defined[3];
	
}_TRA;

extern _TRA traj[10];

void plan_tra(_TRA *tra);
void get_tra(_TRA *tra,float t);

#endif
