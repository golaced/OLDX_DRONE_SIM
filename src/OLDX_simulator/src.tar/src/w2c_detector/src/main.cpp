#include <ros/ros.h>
#include<image_transport/image_transport.h>
#include<cv_bridge/cv_bridge.h>
#include<sensor_msgs/image_encodings.h>
#include<opencv2/imgproc/imgproc.hpp>
#include<opencv2/highgui/highgui.hpp>
#include <nav_msgs/Odometry.h> 
#include "mark_deteck.h"
MarkerRecognizer m_recognizer;
static const std::string OPENCV_WINDOW = "Image window";
using namespace cv;
cv::Mat image,image_rgb,show;
void imageCb(const sensor_msgs::ImageConstPtr& msg)
{
cv_bridge::CvImagePtr cv_ptr;
try
{
cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
}
catch (cv_bridge::Exception& e)
{
ROS_ERROR("cv_bridge exception: %s", e.what());
return;
}

cv::Size InImage_size(640,480);
image=cv_ptr->image;
resize(image, image, InImage_size);
image.copyTo(image_rgb) ;
image.copyTo(show) ;
}


float To_180_degrees(float x)
{
	return (x>180?(x-360):(x<-180?(x+360):x));
}

void q_to_eular(float x,float y,float z,float w,float att[3],float off)
{

att[0] = atan2(2 * (y*z + w*x), w*w - x*x - y*y + z*z)*57.3;
att[1] = asin(-2 * (x*z - w*y))*57.3;
att[2] = atan2(2 * (x*y + w*z), w*w + x*x - y*y - z*z)*57.3;
att[2] = To_180_degrees(atan2(2 * (-x*y - w*z), 2*(w*w+x*x)-1)*57.3+off);

}


nav_msgs::Odometry drone;
float att_drone[3];
void drone_cb(const nav_msgs::Odometry &msg)
{
static int show1;
    //ROS_INFO("Received a drone odom message!");  
    //ROS_INFO("Drone Position:[%f,%f,%f]",msg.pose.pose.position.x ,msg.pose.pose.position.y,msg.pose.pose.position.z);  
    //ROS_INFO("Spd Components:[%f,%f,%f]",msg.twist.twist.linear.x,msg.twist.twist.linear.y,msg.twist.twist.angular.z);  
	drone=msg;
	q_to_eular(msg.pose.pose.orientation.x,msg.pose.pose.orientation.y,
	msg.pose.pose.orientation.z,msg.pose.pose.orientation.w,att_drone,90);
 if(show1++>0){show1=0;
 // ROS_INFO("Drone Att:[%f,%f,%f]",att_drone[0],att_drone[1],att_drone[2]);  
  //ROS_INFO("Car Att:[%f,%f,%f]",car_drone[0],car_drone[1],car_drone[2]);  
  }
}


int main(int argc, char** argv)
{
  ros::init(argc, argv, "image_converter");
  ros::NodeHandle nh;
  ros::Subscriber sub_drone = nh.subscribe("/ground_truth/state", 1, drone_cb);
  ros::Subscriber sub_camera= nh.subscribe("/ardrone/45/image_raw", 1,imageCb);
  ros::Publisher  pub_w2c = nh.advertise<nav_msgs::Odometry>("w2c_pos", 1);
  cv::Size InImage_size(640,480);
  cv::Size InImage_size1(320,240);
	double fx = 421.3612  ;
	double fy = fx  ;
	double u0 = 0;
	double v0 = 0;
	//镜头畸变参数
	double k1 = 0;
	double k2 = 0;
	double p1 = 0;
	double p2 = 0;
	double k3 = 0;
	float out_r=0.75;
	float in_r=71./130.*out_r;
	float r_2d=42./130.*out_r;
	m_recognizer.init_marker(r_2d,r_2d*0.4,out_r/2,in_r/2);
	m_recognizer.SetCameraMatrix(fx, fy, u0, v0);
	m_recognizer.SetDistortionCoefficients(k1, k2, p1, p2, k3);

	ros::Rate loop_rate(100);
	cv::namedWindow(OPENCV_WINDOW);
	while (ros::ok())
	{

		if ( image_rgb.data != nullptr ) //数据不存在,可能是文件不存在
		{
		resize(image_rgb, image_rgb, InImage_size);
		m_recognizer.update(image_rgb, 120,20);
		m_recognizer.drawToImage(show,Scalar(255,0,255),2);
		vector<Marker1>& markers = m_recognizer.getMarkers();

		// Update GUI Window
		resize(show, show, InImage_size1);
		cv::imshow(OPENCV_WINDOW,show);
		}
 		
		nav_msgs::Odometry temp;
		//circle
		if(m_recognizer.m_markers_circle.size()){
		temp.pose.pose.position.x=m_recognizer.pos_circle.x;
		temp.pose.pose.position.y=m_recognizer.pos_circle.y;
		temp.pose.pose.position.z=m_recognizer.pos_circle.z;
		temp.twist.twist.angular.x=m_recognizer.att_circle.z;
		}
		//2d
		#if USE_ARUCO
		if(m_recognizer.Markersa.size()){
		#else
		if(m_recognizer.m_markers.size()){
		#endif
		temp.twist.twist.linear.x=m_recognizer.pos_2d.x;
		temp.twist.twist.linear.y=m_recognizer.pos_2d.y;
		temp.twist.twist.linear.z=m_recognizer.pos_2d.z;
		temp.twist.twist.angular.z=m_recognizer.att_2d.z;
		}
	        pub_w2c.publish(temp);



		cv::waitKey(3);
		ros::spinOnce();
		loop_rate.sleep();
	}
  return 0;
}
